import type { Node, Edge } from '@xyflow/react';

export interface SkillNodeData extends Record<string, unknown> {
  label: string;
  description: string;
  level: number;
  category: SkillCategory;
  projects: string[];
  interviewQuestions: string[];
  resources: { title: string; url: string }[];
  isRoot?: boolean;
}

export type SkillCategory =
  | 'core'
  | 'technical'
  | 'creative'
  | 'soft'
  | 'domain'
  | 'advanced';

export type SkillNode = Node<SkillNodeData>;
export type SkillEdge = Edge;

export interface CareerTree {
  nodes: SkillNode[];
  edges: SkillEdge[];
  jobTitle: string;
  jobSummary: string;
  careerPath: string[];
}
