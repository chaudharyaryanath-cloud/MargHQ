import { useState, type FormEvent } from 'react';
import { Compass, Sparkles, ArrowRight, Zap } from 'lucide-react';

interface JobInputScreenProps {
  onGenerate: (jobTitle: string) => void;
}

const SUGGESTIONS = [
  'UI/UX Designer for Fintech',
  'Full Stack Software Engineer',
  'Data Scientist',
  'Product Manager',
  'Digital Marketing Specialist',
];

export default function JobInputScreen({ onGenerate }: JobInputScreenProps) {
  const [input, setInput] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (trimmed) {
      onGenerate(trimmed);
    }
  };

  const handleSuggestion = (suggestion: string) => {
    setInput(suggestion);
    onGenerate(suggestion);
  };

  return (
    <div className="job-input-screen">
      <div className="job-input-screen__bg-grid" />
      <div className="job-input-screen__bg-glow job-input-screen__bg-glow--1" />
      <div className="job-input-screen__bg-glow job-input-screen__bg-glow--2" />

      <div className="job-input-screen__content">
        <div className="job-input-screen__badge">
          <Sparkles size={14} />
          <span>Skill Tree Explorer</span>
        </div>

        <h1 className="job-input-screen__title">
          Map Your Path to Your
          <br />
          <span className="job-input-screen__title-accent">Dream Career</span>
        </h1>

        <p className="job-input-screen__subtitle">
          Type your dream job and we'll build a visual skill tree — like a video game skill map.
          Click any node to unlock project ideas, interview questions, and learning resources.
        </p>

        <form className="job-input-screen__form" onSubmit={handleSubmit}>
          <div className="job-input-screen__input-wrapper">
            <Compass size={22} className="job-input-screen__input-icon" />
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="e.g., UI/UX Designer for Fintech"
              className="job-input-screen__input"
              autoFocus
            />
            <button
              type="submit"
              className="job-input-screen__submit"
              disabled={!input.trim()}
            >
              <span>Generate Map</span>
              <ArrowRight size={18} />
            </button>
          </div>
        </form>

        <div className="job-input-screen__suggestions">
          <div className="job-input-screen__suggestions-label">
            <Zap size={14} />
            <span>Try one of these</span>
          </div>
          <div className="job-input-screen__suggestion-list">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                className="job-input-screen__suggestion"
                onClick={() => handleSuggestion(s)}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="job-input-screen__features">
          <div className="job-input-screen__feature">
            <div className="job-input-screen__feature-icon">1</div>
            <div className="job-input-screen__feature-text">
              <strong>Visual Skill Map</strong>
              <span>See your career path as an interactive tree</span>
            </div>
          </div>
          <div className="job-input-screen__feature">
            <div className="job-input-screen__feature-icon">2</div>
            <div className="job-input-screen__feature-text">
              <strong>Project Ideas</strong>
              <span>Hands-on projects for every skill</span>
            </div>
          </div>
          <div className="job-input-screen__feature">
            <div className="job-input-screen__feature-icon">3</div>
            <div className="job-input-screen__feature-text">
              <strong>Interview Prep</strong>
              <span>Real questions you'll be asked</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
