import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import {
  Code2,
  Palette,
  Users,
  Briefcase,
  Zap,
  Target,
  ChevronRight,
} from 'lucide-react';
import type { SkillNodeData, SkillCategory } from '@/types/career';

const CATEGORY_CONFIG: Record<
  SkillCategory,
  { icon: typeof Code2; label: string; color: string; bgColor: string; borderColor: string; glowColor: string }
> = {
  core: {
    icon: Target,
    label: 'Core',
    color: '#0ea5e9',
    bgColor: 'rgba(14, 165, 233, 0.12)',
    borderColor: 'rgba(14, 165, 233, 0.5)',
    glowColor: 'rgba(14, 165, 233, 0.35)',
  },
  technical: {
    icon: Code2,
    label: 'Technical',
    color: '#10b981',
    bgColor: 'rgba(16, 185, 129, 0.12)',
    borderColor: 'rgba(16, 185, 129, 0.5)',
    glowColor: 'rgba(16, 185, 129, 0.35)',
  },
  creative: {
    icon: Palette,
    label: 'Creative',
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.12)',
    borderColor: 'rgba(245, 158, 11, 0.5)',
    glowColor: 'rgba(245, 158, 11, 0.35)',
  },
  soft: {
    icon: Users,
    label: 'Soft Skills',
    color: '#ec4899',
    bgColor: 'rgba(236, 72, 153, 0.12)',
    borderColor: 'rgba(236, 72, 153, 0.5)',
    glowColor: 'rgba(236, 72, 153, 0.35)',
  },
  domain: {
    icon: Briefcase,
    label: 'Domain',
    color: '#6366f1',
    bgColor: 'rgba(99, 102, 241, 0.12)',
    borderColor: 'rgba(99, 102, 241, 0.5)',
    glowColor: 'rgba(99, 102, 241, 0.35)',
  },
  advanced: {
    icon: Zap,
    label: 'Advanced',
    color: '#ef4444',
    bgColor: 'rgba(239, 68, 68, 0.12)',
    borderColor: 'rgba(239, 68, 68, 0.5)',
    glowColor: 'rgba(239, 68, 68, 0.35)',
  },
};

function SkillNodeComponent({ data, selected }: NodeProps) {
  const skillData = data as unknown as SkillNodeData;
  const config = CATEGORY_CONFIG[skillData.category];
  const Icon = config.icon;
  const isRoot = skillData.isRoot;

  return (
    <div
      className="skill-node-wrapper"
      style={{
        '--node-color': config.color,
        '--node-bg': config.bgColor,
        '--node-border': config.borderColor,
        '--node-glow': config.glowColor,
      } as React.CSSProperties}
    >
      <Handle
        type="target"
        position={Position.Left}
        style={{
          background: config.color,
          width: isRoot ? 0 : 10,
          height: isRoot ? 0 : 10,
          border: '2px solid #0f172a',
          opacity: isRoot ? 0 : 1,
        }}
      />

      <div
        className={`skill-node ${isRoot ? 'skill-node--root' : ''} ${
          selected ? 'skill-node--selected' : ''
        }`}
      >
        <div className="skill-node__icon" style={{ background: config.color }}>
          <Icon size={isRoot ? 24 : 18} strokeWidth={2.2} />
        </div>

        <div className="skill-node__content">
          <div className="skill-node__category">{config.label}</div>
          <div className="skill-node__label">{skillData.label}</div>
        </div>

        {!isRoot && (
          <div className="skill-node__chevron">
            <ChevronRight size={16} />
          </div>
        )}
      </div>

      <Handle
        type="source"
        position={Position.Right}
        style={{
          background: config.color,
          width: 10,
          height: 10,
          border: '2px solid #0f172a',
        }}
      />
    </div>
  );
}

export default memo(SkillNodeComponent);
