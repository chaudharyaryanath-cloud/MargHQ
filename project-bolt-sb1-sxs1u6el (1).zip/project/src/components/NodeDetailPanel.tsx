import { X, Rocket, MessageSquare, BookOpen, FolderKanban, ExternalLink } from 'lucide-react';
import type { SkillNodeData } from '@/types/career';

interface NodeDetailPanelProps {
  data: SkillNodeData | null;
  onClose: () => void;
}

const CATEGORY_LABELS: Record<string, string> = {
  core: 'Core Skill',
  technical: 'Technical Skill',
  creative: 'Creative Skill',
  soft: 'Soft Skill',
  domain: 'Domain Knowledge',
  advanced: 'Advanced Skill',
};

const CATEGORY_COLORS: Record<string, string> = {
  core: '#0ea5e9',
  technical: '#10b981',
  creative: '#f59e0b',
  soft: '#ec4899',
  domain: '#6366f1',
  advanced: '#ef4444',
};

export default function NodeDetailPanel({ data, onClose }: NodeDetailPanelProps) {
  if (!data) return null;

  const color = CATEGORY_COLORS[data.category] ?? '#0ea5e9';
  const hasProjects = data.projects.length > 0;
  const hasQuestions = data.interviewQuestions.length > 0;
  const hasResources = data.resources.length > 0;

  return (
    <>
      <div className="panel-backdrop" onClick={onClose} />
      <aside className="node-detail-panel" style={{ '--accent': color } as React.CSSProperties}>
        <div className="node-detail-panel__header">
          <div className="node-detail-panel__header-top">
            <span
              className="node-detail-panel__badge"
              style={{ background: `${color}22`, color, border: `1px solid ${color}55` }}
            >
              {CATEGORY_LABELS[data.category] ?? 'Skill'}
            </span>
            <button className="node-detail-panel__close" onClick={onClose} aria-label="Close panel">
              <X size={20} />
            </button>
          </div>
          <h2 className="node-detail-panel__title">{data.label}</h2>
          <p className="node-detail-panel__description">{data.description}</p>
        </div>

        <div className="node-detail-panel__body">
          {hasProjects && (
            <section className="panel-section">
              <div className="panel-section__header">
                <FolderKanban size={18} />
                <h3>Project Ideas</h3>
                <span className="panel-section__count">{data.projects.length}</span>
              </div>
              <ul className="panel-list">
                {data.projects.map((project, i) => (
                  <li key={i} className="panel-list__item panel-list__item--project">
                    <Rocket size={14} className="panel-list__icon" />
                    <span>{project}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {hasQuestions && (
            <section className="panel-section">
              <div className="panel-section__header">
                <MessageSquare size={18} />
                <h3>Interview Questions</h3>
                <span className="panel-section__count">{data.interviewQuestions.length}</span>
              </div>
              <ul className="panel-list">
                {data.interviewQuestions.map((q, i) => (
                  <li key={i} className="panel-list__item panel-list__item--question">
                    <span className="panel-list__number">{i + 1}</span>
                    <span>{q}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {hasResources && (
            <section className="panel-section">
              <div className="panel-section__header">
                <BookOpen size={18} />
                <h3>Learning Resources</h3>
              </div>
              <ul className="panel-list">
                {data.resources.map((res, i) => (
                  <li key={i}>
                    <a
                      href={res.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="panel-resource-link"
                    >
                      <span>{res.title}</span>
                      <ExternalLink size={14} />
                    </a>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {!hasProjects && !hasQuestions && !hasResources && (
            <div className="panel-empty">
              <p>This is your starting point. Click any skill node on the map to see project ideas, interview questions, and learning resources.</p>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
