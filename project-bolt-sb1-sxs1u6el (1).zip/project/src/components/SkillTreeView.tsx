import { useCallback, useMemo, useState } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  type Node,
  type Edge,
  type NodeMouseHandler,
  BackgroundVariant,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import SkillNode from './SkillNode';
import NodeDetailPanel from './NodeDetailPanel';
import type { CareerTree, SkillNodeData } from '@/types/career';

interface SkillTreeViewProps {
  tree: CareerTree;
  onReset: () => void;
}

const nodeTypes = { skill: SkillNode };

const minimapColor = (node: Node) => {
  const data = node.data as unknown as SkillNodeData;
  const colors: Record<string, string> = {
    core: '#0ea5e9',
    technical: '#10b981',
    creative: '#f59e0b',
    soft: '#ec4899',
    domain: '#6366f1',
    advanced: '#ef4444',
  };
  return colors[data.category] ?? '#64748b';
};

export default function SkillTreeView({ tree, onReset }: SkillTreeViewProps) {
  const [selectedData, setSelectedData] = useState<SkillNodeData | null>(null);

  const nodes = useMemo(
    () =>
      tree.nodes.map((n) => ({
        ...n,
        selected: false,
      })) as unknown as Node[],
    [tree.nodes]
  );

  const edges = useMemo(
    () =>
      tree.edges.map((e) => ({
        ...e,
        style: {
          stroke: 'rgba(148, 163, 184, 0.35)',
          strokeWidth: 2,
        },
      })) as Edge[],
    [tree.edges]
  );

  const handleNodeClick: NodeMouseHandler = useCallback((_evt, node) => {
    setSelectedData(node.data as unknown as SkillNodeData);
  }, []);

  return (
    <div className="tree-view">
      <div className="tree-view__topbar">
        <div className="tree-view__topbar-left">
          <button className="tree-view__back" onClick={onReset}>
            <span className="tree-view__back-arrow">&larr;</span>
            New Search
          </button>
        </div>
        <div className="tree-view__topbar-center">
          <h1 className="tree-view__title">{tree.jobTitle}</h1>
          <p className="tree-view__subtitle">{tree.jobSummary}</p>
        </div>
        <div className="tree-view__topbar-right" />
      </div>

      <div className="tree-view__career-path">
        <div className="career-path__label">Career Progression</div>
        <div className="career-path__steps">
          {tree.careerPath.map((step, i) => (
            <div key={i} className="career-path__step">
              <span className="career-path__dot">{i + 1}</span>
              <span className="career-path__name">{step}</span>
              {i < tree.careerPath.length - 1 && (
                <span className="career-path__connector" />
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="tree-view__canvas">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          onNodeClick={handleNodeClick}
          fitView
          fitViewOptions={{ padding: 0.25, maxZoom: 1.2 }}
          minZoom={0.3}
          maxZoom={2}
          proOptions={{ hideAttribution: true }}
          nodesConnectable={false}
          nodesDraggable={false}
        >
          <Background
            variant={BackgroundVariant.Dots}
            gap={22}
            size={1.5}
            color="rgba(148, 163, 184, 0.15)"
          />
          <Controls
            showInteractive={false}
            className="tree-view__controls"
          />
          <MiniMap
            nodeColor={minimapColor}
            maskColor="rgba(15, 23, 42, 0.7)"
            className="tree-view__minimap"
            pannable
            zoomable
          />
        </ReactFlow>

        <div className="tree-view__legend">
          <div className="legend__title">Skill Types</div>
          <div className="legend__items">
            <div className="legend__item"><span style={{ background: '#0ea5e9' }} />Core</div>
            <div className="legend__item"><span style={{ background: '#10b981' }} />Technical</div>
            <div className="legend__item"><span style={{ background: '#f59e0b' }} />Creative</div>
            <div className="legend__item"><span style={{ background: '#ec4899' }} />Soft Skills</div>
            <div className="legend__item"><span style={{ background: '#6366f1' }} />Domain</div>
            <div className="legend__item"><span style={{ background: '#ef4444' }} />Advanced</div>
          </div>
        </div>

        <div className="tree-view__hint">
          Click any node to explore projects &amp; interview questions
        </div>
      </div>

      <NodeDetailPanel data={selectedData} onClose={() => setSelectedData(null)} />
    </div>
  );
}
