import type {
  CareerTree,
  SkillNode,
  SkillEdge,
  SkillCategory,
  SkillNodeData,
} from '@/types/career';

interface RawSkill {
  label: string;
  category: SkillCategory;
  description: string;
  projects: string[];
  interviewQuestions: string[];
  resources: { title: string; url: string }[];
  children?: RawSkill[];
}

// ---------- Category-based keyword skill databases ----------

interface JobProfile {
  matchers: string[];
  title: string;
  summary: string;
  root: RawSkill;
  careerPath: string[];
}

const PROFILES: JobProfile[] = [
  // --- UI/UX Designer ---
  {
    matchers: ['ui', 'ux', 'designer', 'product designer', 'fintech'],
    title: 'UI/UX Designer',
    summary:
      'Design intuitive, beautiful, and accessible user experiences for digital products — from research and wireframes to polished, interactive prototypes.',
    careerPath: [
      'Junior UX Designer',
      'UX Designer',
      'Senior UX Designer',
      'Lead Product Designer',
      'Head of Design',
    ],
    root: {
      label: 'UI/UX Designer',
      category: 'core',
      description:
        'Craft user-centered digital experiences through research, design, and prototyping.',
      projects: [],
      interviewQuestions: [],
      resources: [],
      children: [
        {
          label: 'User Research',
          category: 'soft',
          description:
            'Understand users through interviews, surveys, and usability testing.',
          projects: [
            'Conduct 5 user interviews for a local coffee shop app and write a research brief',
            'Create a survey with Google Forms to study app onboarding pain points (50+ responses)',
            'Run a usability test on an existing app and produce a findings report',
          ],
          interviewQuestions: [
            'Walk me through your user research process for a recent project.',
            'How do you decide between qualitative and quantitative research methods?',
            'Tell me about a time research findings changed your design direction.',
          ],
          resources: [
            { title: 'NN/g – User Research Basics', url: 'https://www.nngroup.com/articles/user-research/' },
            { title: 'IDEO Design Kit', url: 'https://www.designkit.org/methods' },
          ],
          children: [
            {
              label: 'Personas & Journey Mapping',
              category: 'soft',
              description:
                'Synthesize research into personas and map end-to-end user journeys.',
              projects: [
                'Create 3 user personas based on interview data for a fitness app',
                'Map the user journey for booking a flight — identify 3 friction points',
              ],
              interviewQuestions: [
                'How do you create personas from raw research data?',
                'What makes a journey map useful vs. just a deliverable?',
              ],
              resources: [
                { title: 'Nielsen Norman – Journey Mapping', url: 'https://www.nngroup.com/articles/journey-mapping-101/' },
              ],
            },
            {
              label: 'Usability Testing',
              category: 'soft',
              description:
                'Validate designs with real users through moderated and unmoderated tests.',
              projects: [
                'Run a moderated usability test on a Figma prototype with 5 participants',
                'Write a usability test script for a checkout flow',
              ],
              interviewQuestions: [
                'How many participants do you need for usability testing and why?',
                'Describe a time usability testing revealed an unexpected problem.',
              ],
              resources: [
                { title: 'Usability.gov – Testing', url: 'https://www.usability.gov/how-to-and-tools/methods/usability-testing.html' },
              ],
            },
          ],
        },
        {
          label: 'Visual Design',
          category: 'creative',
          description:
            'Apply color theory, typography, and layout principles to create polished interfaces.',
          projects: [
            'Redesign a mobile app screen using a consistent color system and type scale',
            'Create a design system with 10 components in Figma (buttons, inputs, cards)',
            'Design a dark-mode and light-mode version of a dashboard',
          ],
          interviewQuestions: [
            'How do you approach establishing a visual design system?',
            'Talk about a time you used color theory to influence user behavior.',
            'How do you ensure visual consistency across a large product?',
          ],
          resources: [
            { title: 'Refactoring UI', url: 'https://www.refactoringui.com/' },
            { title: 'Material Design 3', url: 'https://m3.material.io/' },
          ],
          children: [
            {
              label: 'Typography & Color',
              category: 'creative',
              description:
                'Master typographic hierarchy and color systems for digital interfaces.',
              projects: [
                'Build a type scale (1.250 ratio) for a blog layout',
                'Create an accessible color palette meeting WCAG AA contrast',
              ],
              interviewQuestions: [
                'What is typographic hierarchy and why does it matter?',
                'How do you test color accessibility in your designs?',
              ],
              resources: [
                { title: 'Type Scale Tool', url: 'https://typescale.com/' },
              ],
            },
            {
              label: 'Design Systems',
              category: 'creative',
              description:
                'Build reusable component libraries and documentation for teams.',
              projects: [
                'Create a Figma component library with auto-layout for 15 components',
                'Document a design system with usage guidelines in Notion',
              ],
              interviewQuestions: [
                'What components would you include in a minimum viable design system?',
                'How do you handle design system governance and contributions?',
              ],
              resources: [
                { title: 'Figma – Design Systems', url: 'https://www.figma.com/best-practices/' },
              ],
            },
          ],
        },
        {
          label: 'Prototyping',
          category: 'technical',
          description:
            'Build interactive prototypes to communicate flows and test interactions.',
          projects: [
            'Create a high-fidelity clickable prototype of a mobile onboarding flow in Figma',
            'Prototype a drag-and-drop interaction using Figma smart animate',
            'Build a micro-interaction prototype (button feedback, loading states)',
          ],
          interviewQuestions: [
            'When do you prototype in low-fidelity vs. high-fidelity?',
            'How do you use prototypes to communicate with developers?',
          ],
          resources: [
            { title: 'Figma Prototyping Guide', url: 'https://help.figma.com/hc/en-us/articles/360040314193-Guide-to-prototyping-in-Figma' },
          ],
        },
        {
          label: 'Fintech Domain',
          category: 'domain',
          description:
            'Understand financial product constraints: security, compliance, and trust.',
          projects: [
            'Design a secure mobile banking dashboard with quick actions',
            'Create a transparent fee-breakdown screen for a payments app',
            'Redesign a loan application form to reduce abandonment',
          ],
          interviewQuestions: [
            'How do you balance security requirements with user experience in fintech?',
            'Design a flow for a user who forgot their banking password — what do you consider?',
            'How would you make complex financial data feel approachable?',
          ],
          resources: [
            { title: 'FinTech Design Patterns', url: 'https://www.fintechdesign.com/' },
          ],
        },
        {
          label: 'Portfolio & Communication',
          category: 'soft',
          description:
            'Present design decisions clearly and build a compelling case-study portfolio.',
          projects: [
            'Write 3 case studies using the problem-process-outcome framework',
                'Create a portfolio website (Framer or Webflow) with 3 projects',
            'Practice presenting a design critique to a developer',
          ],
          interviewQuestions: [
            'Walk me through your favorite portfolio piece — what was your role?',
            'How do you handle feedback that contradicts your design direction?',
            'Describe how you present designs to stakeholders.',
          ],
          resources: [
            { title: 'Bestfolios – Design Portfolios', url: 'https://www.bestfolios.com/' },
          ],
        },
      ],
    },
  },

  // --- Software Engineer ---
  {
    matchers: ['software', 'developer', 'engineer', 'fullstack', 'full stack', 'backend', 'frontend', 'web developer', 'swe'],
    title: 'Software Engineer',
    summary:
      'Build robust, scalable software systems — from frontend interfaces to backend services and databases.',
    careerPath: [
      'Junior Engineer',
      'Software Engineer',
      'Senior Engineer',
      'Staff Engineer',
      'Principal Engineer',
    ],
    root: {
      label: 'Software Engineer',
      category: 'core',
      description:
        'Design, build, and maintain software systems that solve real problems.',
      projects: [],
      interviewQuestions: [],
      resources: [],
      children: [
        {
          label: 'Programming Fundamentals',
          category: 'technical',
          description:
            'Master data structures, algorithms, and core programming concepts.',
          projects: [
            'Solve 50 LeetCode problems (arrays, strings, hash maps, trees)',
            'Build a CLI tool that manages a to-do list with file persistence',
            'Implement a hash map from scratch in your language of choice',
          ],
          interviewQuestions: [
            'Explain the difference between an array and a linked list.',
            'When would you use a hash map vs. a binary search tree?',
            'Walk me through how you would reverse a linked list.',
          ],
          resources: [
            { title: 'LeetCode', url: 'https://leetcode.com/' },
            { title: 'Big-O Cheat Sheet', url: 'https://www.bigocheatsheet.com/' },
          ],
          children: [
            {
              label: 'Data Structures',
              category: 'technical',
              description:
                'Understand arrays, trees, graphs, stacks, queues, and hash maps.',
              projects: [
                'Implement a binary search tree with insert, delete, and search',
                'Build a graph representation and implement BFS and DFS',
              ],
              interviewQuestions: [
                'What is the time complexity of inserting into a balanced BST?',
                'When would you use BFS vs. DFS?',
              ],
              resources: [
                { title: 'VisuAlgo – Data Structures', url: 'https://visualgo.net/' },
              ],
            },
            {
              label: 'Algorithms',
              category: 'technical',
              description:
                'Sorting, searching, dynamic programming, and complexity analysis.',
              projects: [
                'Implement quicksort and mergesort — benchmark them on 10K records',
                'Solve 10 dynamic programming problems on LeetCode',
              ],
              interviewQuestions: [
                'Explain how quicksort works and its worst-case complexity.',
                'What is dynamic programming and when do you use it?',
              ],
              resources: [
                { title: 'Algorithms by Sedgewick', url: 'https://algs4.cs.princeton.edu/home/' },
              ],
            },
          ],
        },
        {
          label: 'Web Development',
          category: 'technical',
          description:
            'Build web applications with modern frontend and backend frameworks.',
          projects: [
            'Build a full-stack CRUD app with React + Node + database',
            'Create a real-time chat app with WebSockets',
            'Deploy a personal portfolio with CI/CD via GitHub Actions',
          ],
          interviewQuestions: [
            'Explain the request-response lifecycle in a web app.',
            'How do you handle authentication in a web application?',
            'What is CORS and why does it matter?',
          ],
          resources: [
            { title: 'MDN Web Docs', url: 'https://developer.mozilla.org/' },
            { title: 'Full Stack Open', url: 'https://fullstackopen.com/' },
          ],
          children: [
            {
              label: 'Frontend (React)',
              category: 'technical',
              description:
                'Component architecture, state management, hooks, and performance.',
              projects: [
                'Build a responsive dashboard with React + Tailwind',
                'Implement a reusable modal and form component library',
              ],
              interviewQuestions: [
                'What is the virtual DOM and how does React use it?',
                'Explain useEffect cleanup and when you need it.',
                'How do you optimize React app performance?',
              ],
              resources: [
                { title: 'React Docs', url: 'https://react.dev/' },
              ],
            },
            {
              label: 'Backend & APIs',
              category: 'technical',
              description:
                'REST, GraphQL, databases, authentication, and server architecture.',
              projects: [
                'Build a REST API with CRUD + JWT authentication',
                'Design a database schema for an e-commerce store',
              ],
              interviewQuestions: [
                'REST vs. GraphQL — when do you choose each?',
                'How do you design a database schema for a many-to-many relationship?',
                'Explain JWT authentication flow.',
              ],
              resources: [
                { title: 'REST API Tutorial', url: 'https://restfulapi.net/' },
              ],
            },
          ],
        },
        {
          label: 'System Design',
          category: 'advanced',
          description:
            'Design scalable, reliable distributed systems and services.',
          projects: [
            'Design a URL shortener — draw the architecture diagram',
            'Design a Twitter-like feed system for 1M users',
            'Write a design doc for a notification service',
          ],
          interviewQuestions: [
            'Design a rate limiter — what data structure would you use?',
            'How would you design a chat system that handles 10K concurrent users?',
            'What is eventual consistency and when is it acceptable?',
          ],
          resources: [
            { title: 'System Design Primer', url: 'https://github.com/donnemartin/system-design-primer' },
            { title: 'ByteByteGo', url: 'https://bytebytego.com/' },
          ],
        },
        {
          label: 'Version Control & DevOps',
          category: 'technical',
          description:
            'Git workflows, CI/CD pipelines, containers, and cloud deployment.',
          projects: [
            'Set up a GitHub Actions CI pipeline that runs tests on every PR',
            'Dockerize a Node app and deploy it to a cloud provider',
            'Practice a Git rebase and cherry-pick workflow on a sample repo',
          ],
          interviewQuestions: [
            'Explain the difference between Git merge and rebase.',
            'How do you handle merge conflicts in a team setting?',
            'Describe your ideal CI/CD pipeline.',
          ],
          resources: [
            { title: 'Git Pro Book', url: 'https://git-scm.com/book/en/v2' },
            { title: 'Docker Docs', url: 'https://docs.docker.com/' },
          ],
        },
        {
          label: 'Soft Skills & Teamwork',
          category: 'soft',
          description:
            'Code reviews, pair programming, technical communication, and agile practices.',
          projects: [
            'Contribute to an open-source project (fix a "good first issue")',
            'Write a technical blog post explaining a concept you learned',
            'Do 5 pair-programming sessions with a classmate',
          ],
          interviewQuestions: [
            'Tell me about a time you disagreed with a technical decision.',
            'How do you approach giving and receiving code review feedback?',
            'Describe a bug that took you a long time to find — what did you learn?',
          ],
          resources: [
            { title: 'First Round Review – Engineering', url: 'https://review.firstround.com/' },
          ],
        },
      ],
    },
  },

  // --- Data Scientist ---
  {
    matchers: ['data scientist', 'data analyst', 'machine learning', 'ml', 'ai', 'data', 'analytics'],
    title: 'Data Scientist',
    summary:
      'Extract insights from data through statistical analysis, machine learning, and data storytelling.',
    careerPath: [
      'Data Analyst',
      'Data Scientist',
      'Senior Data Scientist',
      'Lead ML Engineer',
      'Head of Data',
    ],
    root: {
      label: 'Data Scientist',
      category: 'core',
      description:
        'Turn raw data into actionable insights and predictive models.',
      projects: [],
      interviewQuestions: [],
      resources: [],
      children: [
        {
          label: 'Statistics & Math',
          category: 'technical',
          description:
            'Probability, hypothesis testing, linear algebra, and calculus for ML.',
          projects: [
            'Analyze a Kaggle dataset — compute descriptive stats and 3 visualizations',
            'Run an A/B test simulation and interpret the p-value',
            'Implement linear regression from scratch with NumPy',
          ],
          interviewQuestions: [
            'Explain the Central Limit Theorem and why it matters.',
            'What is the difference between correlation and causation?',
            'How do you interpret a p-value of 0.03?',
          ],
          resources: [
            { title: 'Khan Academy – Statistics', url: 'https://www.khanacademy.org/math/statistics-probability' },
            { title: 'Kaggle', url: 'https://www.kaggle.com/' },
          ],
        },
        {
          label: 'Python & Data Tools',
          category: 'technical',
          description:
            'Pandas, NumPy, Jupyter, and data wrangling at scale.',
          projects: [
            'Clean and analyze a messy CSV dataset with Pandas — produce a report',
            'Build a data pipeline that fetches, transforms, and stores data',
            'Create a Jupyter notebook analyzing housing prices',
          ],
          interviewQuestions: [
            'How do you handle missing data in a dataset?',
            'Explain the difference between merge, join, and concatenate in Pandas.',
            'How do you optimize Pandas operations for large datasets?',
          ],
          resources: [
            { title: 'Pandas Docs', url: 'https://pandas.pydata.org/docs/' },
          ],
        },
        {
          label: 'Machine Learning',
          category: 'advanced',
          description:
            'Supervised, unsupervised learning, model evaluation, and deployment.',
          projects: [
            'Build a spam classifier with scikit-learn (logistic regression)',
            'Train a decision tree to predict customer churn — tune hyperparameters',
            'Deploy an ML model as a REST API using FastAPI',
          ],
          interviewQuestions: [
            'How do you prevent overfitting in a machine learning model?',
            'Explain the bias-variance tradeoff.',
            'What evaluation metrics would you use for an imbalanced classification problem?',
          ],
          resources: [
            { title: 'scikit-learn Tutorials', url: 'https://scikit-learn.org/stable/tutorial/' },
            { title: 'Hands-On ML Book', url: 'https://www.oreilly.com/library/view/hands-on-machine-learning/9781098125967/' },
          ],
          children: [
            {
              label: 'Deep Learning',
              category: 'advanced',
              description:
                'Neural networks, PyTorch/TensorFlow, CNNs, RNNs, and transformers.',
              projects: [
                'Build an image classifier with a CNN on the CIFAR-10 dataset',
                'Fine-tune a pre-trained transformer for sentiment analysis',
              ],
              interviewQuestions: [
                'Explain backpropagation in simple terms.',
                'What is the vanishing gradient problem and how do you address it?',
                'When would you use a CNN vs. an RNN?',
              ],
              resources: [
                { title: 'PyTorch Tutorials', url: 'https://pytorch.org/tutorials/' },
              ],
            },
          ],
        },
        {
          label: 'Data Visualization',
          category: 'creative',
          description:
            'Tell compelling stories with data using charts, dashboards, and narratives.',
          projects: [
            'Build an interactive dashboard with Plotly or Streamlit',
            'Create a data storytelling presentation for a non-technical audience',
            'Design 5 chart types that best communicate different data patterns',
          ],
          interviewQuestions: [
            'How do you choose the right chart type for your data?',
            'Describe a time you presented data insights that changed a decision.',
            'What makes a dashboard effective vs. cluttered?',
          ],
          resources: [
            { title: 'Storytelling with Data', url: 'https://www.storytellingwithdata.com/' },
          ],
        },
        {
          label: 'SQL & Databases',
          category: 'technical',
          description:
            'Query relational databases, window functions, and performance optimization.',
          projects: [
            'Write 20 SQL queries on a sample database — joins, subqueries, window functions',
            'Design a star schema for a data warehouse',
          ],
          interviewQuestions: [
            'What is the difference between WHERE and HAVING?',
            'Explain how a window function works with an example.',
            'How do you optimize a slow SQL query?',
          ],
          resources: [
            { title: 'SQLZoo', url: 'https://sqlzoo.net/' },
            { title: 'Mode SQL Tutorial', url: 'https://mode.com/sql/tutorial/' },
          ],
        },
      ],
    },
  },

  // --- Product Manager ---
  {
    matchers: ['product manager', 'pm', 'product', 'product owner'],
    title: 'Product Manager',
    summary:
      'Define product vision, prioritize features, and lead cross-functional teams to build products users love.',
    careerPath: [
      'Associate PM',
      'Product Manager',
      'Senior PM',
      'Group Product Manager',
      'VP of Product',
    ],
    root: {
      label: 'Product Manager',
      category: 'core',
      description:
        'Drive product strategy, execution, and cross-functional alignment.',
      projects: [],
      interviewQuestions: [],
      resources: [],
      children: [
        {
          label: 'Product Strategy',
          category: 'soft',
          description:
            'Define vision, roadmap, prioritization, and competitive analysis.',
          projects: [
            'Write a PRD (Product Requirements Document) for a new feature',
            'Create a competitive analysis matrix for 3 products in a market',
            'Build a 6-month product roadmap with prioritized initiatives',
          ],
          interviewQuestions: [
            'How do you prioritize features when everything is "urgent"?',
            'Walk me through how you would build a roadmap from scratch.',
            'How do you decide what NOT to build?',
          ],
          resources: [
            { title: 'Lenny’s Newsletter', url: 'https://www.lennysnewsletter.com/' },
            { title: 'Reforge', url: 'https://www.reforge.com/' },
          ],
        },
        {
          label: 'User Research & Data',
          category: 'domain',
          description:
            'Use qualitative and quantitative data to inform product decisions.',
          projects: [
            'Define 3 key metrics (North Star, activation, retention) for an app',
            'Conduct a cohort analysis on sample user data',
            'Write 5 user interview questions for a new feature',
          ],
          interviewQuestions: [
            'What metrics would you track for a mobile onboarding flow?',
            'How do you balance quantitative data with qualitative feedback?',
            'Explain cohort analysis and why it matters for retention.',
          ],
          resources: [
            { title: 'Amplitude – Product Analytics', url: 'https://amplitude.com/blog' },
          ],
        },
        {
          label: 'Execution & Delivery',
          category: 'technical',
          description:
            'Sprint planning, specs, working with engineering, and shipping on time.',
          projects: [
            'Write detailed user stories with acceptance criteria for a feature',
            'Run a mock sprint planning session with a team',
            'Create a spec for an API integration feature',
          ],
          interviewQuestions: [
            'How do you work with engineering to estimate and deliver features?',
            'What do you do when a sprint is falling behind?',
            'Describe your process for writing a feature spec.',
          ],
          resources: [
            { title: 'Atlassian Agile Coach', url: 'https://www.atlassian.com/agile' },
          ],
        },
        {
          label: 'Stakeholder Communication',
          category: 'soft',
          description:
            'Align executives, sales, and engineering around product decisions.',
          projects: [
            'Create a product update presentation for executives',
            'Write a go-to-market brief for a new feature launch',
          ],
          interviewQuestions: [
            'How do you handle a stakeholder who wants a feature you deprioritized?',
            'Describe how you communicate bad news about a slipped deadline.',
          ],
          resources: [
            { title: 'SVPG – Product Management', url: 'https://svpg.com/' },
          ],
        },
      ],
    },
  },

  // --- Digital Marketer ---
  {
    matchers: ['marketing', 'marketer', 'digital marketing', 'seo', 'growth', 'content'],
    title: 'Digital Marketing Specialist',
    summary:
      'Drive growth through SEO, content marketing, paid campaigns, and data-driven experimentation.',
    careerPath: [
      'Marketing Coordinator',
      'Digital Marketing Specialist',
      'Marketing Manager',
      'Head of Growth',
      'CMO',
    ],
    root: {
      label: 'Digital Marketing',
      category: 'core',
      description:
        'Grow brands and revenue through digital channels and data-driven campaigns.',
      projects: [],
      interviewQuestions: [],
      resources: [],
      children: [
        {
          label: 'SEO & Content',
          category: 'domain',
          description:
            'Search engine optimization, keyword research, and content strategy.',
          projects: [
            'Do keyword research for a blog — identify 20 target keywords',
            'Write 3 SEO-optimized blog posts (1500+ words each)',
            'Audit a website’s on-page SEO and produce an action report',
          ],
          interviewQuestions: [
            'How do you approach keyword research for a new product?',
            'What on-page SEO factors matter most in 2025?',
            'How do you measure content marketing ROI?',
          ],
          resources: [
            { title: 'Ahrefs Blog', url: 'https://ahrefs.com/blog/' },
            { title: 'Moz – SEO Guide', url: 'https://moz.com/beginners-guide-to-seo' },
          ],
        },
        {
          label: 'Paid Advertising',
          category: 'technical',
          description:
            'Google Ads, Meta Ads, campaign structure, and budget optimization.',
          projects: [
            'Set up a mock Google Ads campaign with 3 ad groups',
            'Create a Meta Ads creative brief for a product launch',
            'Analyze a sample ad campaign report — identify 3 optimization opportunities',
          ],
          interviewQuestions: [
            'How do you structure a Google Ads campaign for a new product?',
            'What metrics do you optimize for in a performance marketing campaign?',
            'How do you allocate budget across channels?',
          ],
          resources: [
            { title: 'Google Ads Help', url: 'https://support.google.com/google-ads/' },
          ],
        },
        {
          label: 'Analytics & Data',
          category: 'technical',
          description:
            'GA4, conversion tracking, funnel analysis, and attribution models.',
          projects: [
            'Set up GA4 events for an e-commerce site',
            'Build a conversion funnel report in Google Looker Studio',
          ],
          interviewQuestions: [
            'Explain the difference between last-click and data-driven attribution.',
            'How do you set up conversion tracking in GA4?',
          ],
          resources: [
            { title: 'GA4 Academy', url: 'https://academy.exceedlms.com/student/catalog' },
          ],
        },
        {
          label: 'Social & Email',
          category: 'creative',
          description:
            'Social media strategy, email marketing automation, and community building.',
          projects: [
            'Design a 4-week email nurture sequence for a SaaS product',
            'Create a social media content calendar for 1 month',
          ],
          interviewQuestions: [
            'How do you measure social media success beyond vanity metrics?',
            'Describe an email marketing funnel that worked well.',
          ],
          resources: [
            { title: 'HubSpot Academy', url: 'https://academy.hubspot.com/' },
          ],
        },
      ],
    },
  },
];

// ---------- Fallback generic profile ----------

const GENERIC_PROFILE: JobProfile = {
  matchers: [],
  title: '',
  summary:
    'Build the skills and experience needed to land your dream job through hands-on projects and practice.',
  careerPath: [
    'Entry Level',
    'Mid Level',
    'Senior Level',
    'Lead',
    'Director',
  ],
  root: {
    label: '',
    category: 'core',
    description:
      'Your dream career — start by building the foundational skills below.',
    projects: [],
    interviewQuestions: [],
    resources: [],
    children: [
      {
        label: 'Foundational Skills',
        category: 'technical',
        description:
          'Master the core technical skills required for your field.',
        projects: [
          'Take an online course and build a capstone project',
          'Create a cheat sheet of the top 10 concepts in your field',
          'Join a community or Discord related to your field and participate weekly',
        ],
        interviewQuestions: [
          'What are the most important skills for this role?',
          'How did you learn the fundamentals of your field?',
          'What resources do you recommend for someone starting out?',
        ],
        resources: [
          { title: 'Coursera', url: 'https://www.coursera.org/' },
          { title: 'freeCodeCamp', url: 'https://www.freecodecamp.org/' },
        ],
      },
      {
        label: 'Portfolio Projects',
        category: 'creative',
        description:
          'Build real projects that demonstrate your skills to employers.',
        projects: [
          'Build 3 projects that showcase different skills',
          'Document each project with a README and screenshots',
          'Publish your projects on GitHub and a personal site',
        ],
        interviewQuestions: [
          'Walk me through a project you are most proud of.',
          'What challenges did you face and how did you overcome them?',
          'How do you decide what to build next?',
        ],
        resources: [
          { title: 'GitHub', url: 'https://github.com/' },
        ],
      },
      {
        label: 'Industry Knowledge',
        category: 'domain',
        description:
          'Understand the industry, trends, and key companies in your field.',
        projects: [
          'Research 5 companies in your field — write what they do and their tech stack',
          'Read 3 industry reports and summarize key trends',
          'Follow 10 thought leaders on LinkedIn',
        ],
        interviewQuestions: [
          'What trends are you most excited about in this industry?',
          'Which companies do you admire and why?',
          'How do you stay up to date with industry developments?',
        ],
        resources: [
          { title: 'LinkedIn Learning', url: 'https://www.linkedin.com/learning/' },
        ],
      },
      {
        label: 'Networking & Communication',
        category: 'soft',
        description:
          'Build relationships, practice interviewing, and communicate your value.',
        projects: [
          'Attend 3 networking events or virtual meetups',
          'Practice 10 mock interviews with a peer or mentor',
          'Optimize your LinkedIn profile with a strong headline and summary',
        ],
        interviewQuestions: [
          'Tell me about yourself.',
          'Why are you interested in this role?',
          'Where do you see yourself in 5 years?',
        ],
        resources: [
          { title: 'LinkedIn', url: 'https://www.linkedin.com/' },
        ],
      },
      {
        label: 'Job Search Strategy',
        category: 'soft',
        description:
          'Create a structured approach to finding and landing the right job.',
        projects: [
          'Create a target list of 20 companies with contacts',
          'Tailor your resume for 3 different roles',
          'Set up job alerts on 3 platforms',
        ],
        interviewQuestions: [
          'Why are you looking for a new opportunity?',
          'What is your ideal work environment?',
          'How do you handle rejection during the job search?',
        ],
        resources: [
          { title: 'Indeed', url: 'https://www.indeed.com/' },
        ],
      },
    ],
  },
};

// ---------- Matching logic ----------

function matchProfile(input: string): JobProfile {
  const lower = input.toLowerCase().trim();

  let bestMatch: JobProfile | null = null;
  let bestScore = 0;

  for (const profile of PROFILES) {
    let score = 0;
    for (const matcher of profile.matchers) {
      if (lower.includes(matcher)) {
        score += matcher.split(' ').length; // longer matches score higher
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = profile;
    }
  }

  if (bestMatch && bestScore > 0) {
    return bestMatch;
  }

  // Return generic with the user's input as title
  return {
    ...GENERIC_PROFILE,
    title: input.trim(),
    root: {
      ...GENERIC_PROFILE.root,
      label: input.trim(),
    },
  };
}

// ---------- Tree builder: converts RawSkill hierarchy into React Flow nodes/edges ----------

const HORIZONTAL_GAP = 80;
const VERTICAL_GAP = 220;
const NODE_WIDTH = 240;
const ROOT_Y = 0;

let nodeIdCounter = 0;

function nextId(): string {
  nodeIdCounter += 1;
  return `skill-${nodeIdCounter}`;
}

interface LayoutResult {
  nodes: SkillNode[];
  edges: SkillEdge[];
}

function buildTree(
  raw: RawSkill,
  depth: number,
  parentId: string | null,
  parentY: number
): { id: string; x: number; y: number; data: SkillNodeData; children: RawSkill[] } & LayoutResult {
  const id = nextId();
  const y = parentY;

  const data: SkillNodeData = {
    label: raw.label,
    description: raw.description,
    level: depth,
    category: raw.category,
    projects: raw.projects,
    interviewQuestions: raw.interviewQuestions,
    resources: raw.resources,
    isRoot: depth === 0,
  };

  const children = raw.children ?? [];

  // Leaf node — just return self
  if (children.length === 0) {
    return {
      id,
      x: 0,
      y,
      data,
      children,
      nodes: [
        {
          id,
          type: 'skill',
          position: { x: 0, y },
          data,
        },
      ],
      edges: parentId
        ? [{ id: `e-${parentId}-${id}`, source: parentId, target: id, type: 'smoothstep' }]
        : [],
    };
  }

  // Recursively build children
  const childResults = children.map((child, _idx) =>
    buildTree(child, depth + 1, id, y)
  );

  // Gather all descendant nodes and edges
  let allDescendantNodes: SkillNode[] = [];
  let allDescendantEdges: SkillEdge[] = [];

  for (const result of childResults) {
    allDescendantNodes = allDescendantNodes.concat(result.nodes);
    allDescendantEdges = allDescendantEdges.concat(result.edges);
  }

  // Layout: place children vertically stacked, centered relative to parent
  // We need to calculate the total height span of children
  const childCount = childResults.length;
  const totalChildHeight = childCount * VERTICAL_GAP;
  let childY = y - totalChildHeight / 2 + VERTICAL_GAP / 2;

  // Assign x based on depth and y based on stacking
  const childX = depth * (NODE_WIDTH + HORIZONTAL_GAP) + NODE_WIDTH;

  const positionedChildNodes: SkillNode[] = [];
  for (const result of childResults) {
    // Offset all nodes in this child subtree
    for (const node of result.nodes) {
      positionedChildNodes.push({
        ...node,
        position: {
          x: node.position.x + childX,
          y: node.position.y + childY - y, // relative offset from child root
        },
      });
    }
    childY += VERTICAL_GAP;
  }

  // The parent node itself
  const parentX = depth === 0 ? 0 : depth * (NODE_WIDTH + HORIZONTAL_GAP) - NODE_WIDTH;
  const parentNode: SkillNode = {
    id,
    type: 'skill',
    position: { x: parentX, y },
    data,
  };

  // Edge from parent to each child
  const parentEdges: SkillEdge[] = childResults.map(
    (result) => ({
      id: `e-${id}-${result.id}`,
      source: id,
      target: result.id,
      type: 'smoothstep',
    })
  );

  return {
    id,
    x: parentX,
    y,
    data,
    children,
    nodes: [parentNode, ...positionedChildNodes],
    edges: [...parentEdges, ...allDescendantEdges],
  };
}

export function generateCareerTree(jobInput: string): CareerTree {
  nodeIdCounter = 0;

  const profile = matchProfile(jobInput);

  const result = buildTree(profile.root, 0, null, ROOT_Y);

  // Center the root node vertically
  const rootCenterY = 0;
  const allNodes = result.nodes;
  const allEdges = result.edges;

  // Compute bounding box and re-center
  const minY = Math.min(...allNodes.map((n) => n.position.y));
  const maxY = Math.max(...allNodes.map((n) => n.position.y));
  const centerOffset = rootCenterY - (minY + maxY) / 2;

  const centeredNodes = allNodes.map((node) => ({
    ...node,
    position: {
      x: node.position.x,
      y: node.position.y + centerOffset,
    },
  }));

  return {
    nodes: centeredNodes,
    edges: allEdges,
    jobTitle: profile.title,
    jobSummary: profile.summary,
    careerPath: profile.careerPath,
  };
}
