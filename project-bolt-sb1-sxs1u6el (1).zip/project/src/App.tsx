import { useState, useMemo } from 'react';
import JobInputScreen from '@/components/JobInputScreen';
import SkillTreeView from '@/components/SkillTreeView';
import { generateCareerTree } from '@/data/careerTreeGenerator';
import type { CareerTree } from '@/types/career';

export default function App() {
  const [tree, setTree] = useState<CareerTree | null>(null);

  const handleGenerate = useMemo(
    () => (jobTitle: string) => {
      const generated = generateCareerTree(jobTitle);
      setTree(generated);
    },
    []
  );

  const handleReset = () => {
    setTree(null);
  };

  if (!tree) {
    return <JobInputScreen onGenerate={handleGenerate} />;
  }

  return <SkillTreeView tree={tree} onReset={handleReset} />;
}
